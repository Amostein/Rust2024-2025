use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use serde::{Serialize, Deserialize};
use std::io::{Read, Write};
use rand::Rng;

#[derive(Serialize, Deserialize,Debug, Clone, PartialEq)]
enum PlayerTurn {
    Mouse,
    Obstacle,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
enum Message {
    JoinRoom { room: String, client_name: String },
    PlayerMove { x: usize, y: usize },
    UpdateState { tabela: [[i32; 13]; 13], player_turn: PlayerTurn },
    GameResult(i32),
    RequestState,
}


struct GameState {
    tabela: [[i32; 13]; 13],
    player_turn: PlayerTurn,
    pos_x: usize,
    pos_y: usize,
    game_result: i32,
    players_connected: usize,
}
fn is_mouse_trapped(a: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if y % 2 == 0 {
        if x > 0 && y > 0 && a[y - 1][x] != 7 { return false; }
        if y > 0 && x < a[0].len() - 1 && a[y - 1][x + 1] != 7 { return false; }
        if x < a[0].len() - 1 && a[y][x + 1] != 7 { return false; }
        if y < a.len() - 1 && x < a[0].len() - 1 && a[y + 1][x + 1] != 7 { return false; }
        if y < a.len() - 1 && x > 0 && a[y + 1][x] != 7 { return false; }
        if x > 0 && a[y][x - 1] != 7 { return false; }
    } else {
        if y > 0 && x > 0 && a[y - 1][x - 1] != 7 { return false; }                 // stg
        if y > 0 && a[y - 1][x] != 7 { return false; }                              // dr sus
        if x < a[0].len() - 1 && a[y][x + 1] != 7 { return false; }                 // dr
        if y < a.len() - 1 && a[y + 1][x] != 7 { return false; }                    // dr jos
        if y < a.len() - 1 && x > 0 && a[y + 1][x - 1] != 7 { return false; }       // stg jos
        if x > 0 && a[y][x - 1] != 7 { return false; }                              // stg
    }
    true
}
fn check_win(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    tabela[y][x] == 9
}

fn handle_client(mut stream: TcpStream, state: Arc<Mutex<GameState>>, role: PlayerTurn) -> std::io::Result<()> {
    let mut buffer = [0; 512];

    loop {
        let bytes_read = stream.read(&mut buffer)?;
        if bytes_read == 0 {
            break;
        }

        let msg: Message = match serde_json::from_slice(&buffer[..bytes_read]) {
            Ok(msg) => msg,
            Err(e) => {
                eprintln!("Eroare la deserializarea mesajului: {:?}", e);
                continue;
            }
        };

        println!("Received: {:?}", msg);

        match msg {
            Message::JoinRoom { room, client_name } => {
                println!("Clientul '{}' s-a alăturat camerei '{}'.", client_name, room);
            
                let game_state = state.lock().unwrap();
                
                // Trimitem starea curentă clientului
                let response = Message::UpdateState {
                    tabela: game_state.tabela,
                    player_turn: role.clone(), // Trimitem rolul acestui client
                };
                let response_data = serde_json::to_vec(&response).unwrap();
                stream.write_all(&response_data)?; // Trimitere starea către client
            }
            
            Message::PlayerMove { x, y } => {
                let mut game_state = state.lock().unwrap();
                if game_state.player_turn == role {
                    if role == PlayerTurn::Mouse && game_state.tabela[y][x] == 0 {
                        let (old_x, old_y) = (game_state.pos_x, game_state.pos_y);

                        game_state.pos_x = x;
                        game_state.pos_y = y;

                        game_state.tabela[old_y][old_x] = 0;
                        game_state.tabela[y][x] = 1;
                        if is_mouse_trapped(&game_state.tabela, x, y) {
                            game_state.game_result = 2; // Șoarecele este blocat
                        } else if check_win(&game_state.tabela, x, y) {
                            game_state.game_result = 1; // Șoarecele a evadat
                        } else {
                            game_state.player_turn = PlayerTurn::Obstacle;
                        }
                    } else if role == PlayerTurn::Obstacle && game_state.tabela[y][x] == 0 {
                        game_state.tabela[y][x] = 7;
                        game_state.player_turn = PlayerTurn::Mouse;
                        }
                    }

                let response = Message::UpdateState {
                    tabela: game_state.tabela,
                    player_turn: game_state.player_turn.clone(),
                };
                let response_data = serde_json::to_vec(&response).unwrap();
                stream.write_all(&response_data)?;
            }
            Message::RequestState => {
                let game_state = state.lock().unwrap();
                let response = Message::UpdateState {
                    tabela: game_state.tabela,
                    player_turn: game_state.player_turn.clone(),
                };
                let response_data = serde_json::to_vec(&response).unwrap();
                stream.write_all(&response_data)?;
            }
            _ => {}
        }
    }
    Ok(())
}

fn casuta_libera(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if x >= tabela[0].len() || y >= tabela.len() {
        return false;
    }
    tabela[y][x] != 1 && tabela[y][x] != 7 && tabela[y][x] != 9
}
fn init_tabela(tabela: &mut [[i32; 13]; 13]) {
    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            tabela[y][x] = 0;
        }
    }

    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            if x == 0 || x == 12 || y == 0 || y == 12 {
                tabela[y][x] = 9;
            }
        }
    }

    tabela[6][6] = 1; 
    let mut rng = rand::thread_rng();
    let nr_random = rng.gen_range(4..7);
    let mut gata = 0;
    while gata < nr_random {
        let rx = rng.gen_range(1..11);
        let ry = rng.gen_range(1..11);
        if casuta_libera(tabela, rx, ry) {
            tabela[rx][ry] = 7;
            gata += 1;
        }
    }
}

fn main() -> std::io::Result<()> {
    let game_state = Arc::new(Mutex::new(GameState {
        tabela: [[0; 13]; 13],
        player_turn: PlayerTurn::Mouse,
        pos_x: 6,
        pos_y: 6,
        game_result: 0,
        players_connected: 0,
    }));

    {
        let mut game_state = game_state.lock().unwrap();
        init_tabela(&mut game_state.tabela);
    }

    let listener = TcpListener::bind("127.0.0.1:12345")?;
    println!("Serverul ruleaza pe 127.0.0.1:12345");

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let game_state = Arc::clone(&game_state);
                thread::spawn(move || {
                    let role = {
                        let mut state = game_state.lock().unwrap();
                        state.players_connected += 1;
                        match state.players_connected {
                            1 => PlayerTurn::Mouse,
                            2 => PlayerTurn::Obstacle,
                            _ => {
                                println!("Prea mulți jucători conectați. Conexiunea este refuzată.");
                                return;
                            }
                        }
                    };
                    println!("Rol atribuit clientului: {:?}", role);
                    if let Err(e) = handle_client(stream, game_state, role) {
                        eprintln!("Eroare la gestionarea clientului: {:?}", e);
                    }
                });
            }
            Err(e) => eprintln!("Eroare la acceptarea conexiunii: {:?}", e),
        }
    }
    Ok(())
}