use std::net::TcpStream;
use serde::{Serialize, Deserialize};
use std::io::{Write, Read};
use ggez::{Context, GameResult, graphics, ContextBuilder, event};
use ggez::nalgebra as na;
use ggez::event::{MouseButton, KeyCode, KeyMods, EventHandler};

#[derive(Serialize, Deserialize, Debug)]
enum PlayerTurn {
    Mouse,
    Obstacle,
}

#[derive(Serialize, Deserialize, Debug)]
enum Message {
    JoinRoom { room: String, client_name: String },
    PlayerMove { x: usize, y: usize },
    UpdateState { tabela: [[i32; 13]; 13], player_turn: PlayerTurn },
    GameResult(i32),
    RequestState,
}

struct Client {
    stream: TcpStream,
}

impl Client {
    fn send_message(&mut self, msg: Message) {
        let mut data = serde_json::to_vec(&msg).unwrap();
        data.push(b'\n');
        self.stream.write_all(&data).unwrap();
    }

    fn receive_message(&mut self) -> Result<Message, std::io::Error> {
        let mut buffer = vec![0; 4096];
        let bytes_read = self.stream.read(&mut buffer)?;
        let data = &buffer[..bytes_read];
        match serde_json::from_slice(data) {
            Ok(message) => Ok(message),
            Err(err) => {
                eprintln!("Eroare la deserializare: {:?}", err);
                Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "Deserializare esuata"))
            }
        }
    }
    fn request_state(&mut self) {
        self.send_message(Message::RequestState);
    }
}

struct MainState {
    client: Client,
    tabela: [[i32; 13]; 13],
    pos_x: usize,
    pos_y: usize,
    game_result: i32,
    player_turn: PlayerTurn,
}

impl MainState {
    fn new(client: Client) -> GameResult<MainState> {
        Ok(MainState {
            client,
            tabela: [[0; 13]; 13],
            pos_x: 6,
            pos_y: 6,
            game_result: 0,
            player_turn: PlayerTurn::Mouse,
        })
    }
}

fn casuta_libera(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if x >= tabela[0].len() || y >= tabela.len() {
        return false;
    }
    tabela[y][x] != 1 && tabela[y][x] != 7 && tabela[y][x] != 9
}

fn casuta_libera_mouse(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if x >= tabela[0].len() || y >= tabela.len() {
        return false;
    }
    tabela[y][x] != 7
}

fn place_obstacol(tabela: &mut [[i32; 13]; 13], x: usize, y: usize) {
    if casuta_libera(tabela, x, y) {
        tabela[y][x] = 7;
        println!("Obstacol plasat la coordonatele ({}, {}).", x, y);
    } else {
        println!("Coordonate invalide sau loc ocupat! Obstacolul nu a fost plasat.");
    }
}

fn draw_hexagon(ctx: &mut Context, x: f32, y: f32, color: graphics::Color) -> GameResult<()> {
    let points = [
        na::Point2::new(x, y),
        na::Point2::new(x - 17.0, y - 10.0),
        na::Point2::new(x - 17.0, y - 30.0),
        na::Point2::new(x, y - 40.0),
        na::Point2::new(x + 18.0, y - 30.0),
        na::Point2::new(x + 18.0, y - 10.0),
    ];

    let mesh = graphics::Mesh::new_polygon(ctx, graphics::DrawMode::fill(), &points, color)?;
    graphics::draw(ctx, &mesh, graphics::DrawParam::default())?;
    Ok(())
}

fn draw_status(ctx: &mut Context, player_turn: &PlayerTurn, game_result: i32) -> GameResult<()> {
    if game_result != 0 {
        let text1 = match game_result {
            2 => "Soarecele este blocat.",
            1 => "Soarecele a evadat.",
            _ => return Ok(()),
        };

        let status_text = graphics::Text::new((text1, graphics::Font::default(), 24.0));
        let pos = na::Point2::new(600.0, 250.0);
        graphics::draw(ctx, &status_text, (pos, graphics::BLACK))?;
        return Ok(());
    }

    let text = match player_turn {
        PlayerTurn::Obstacle => "Este randul pentru obstacole.",
        PlayerTurn::Mouse => "Este randul soarecelui.",
    };

    let status_text = graphics::Text::new((text, graphics::Font::default(), 24.0));
    let pos = na::Point2::new(600.0, 100.0); // Poziția textului în partea dreaptă
    graphics::draw(ctx, &status_text, (pos, graphics::BLACK))?;

    Ok(())
}


fn afiseaza_tabela(ctx: &mut Context, tabela: &[[i32; 13]; 13]) -> GameResult<()> {
    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            let mut x_pos = (x as f32 * 37.0) + 50.0;
            let y_pos = (y as f32 * 32.0) + 50.0;
            if y % 2 == 0 {
                x_pos += 17.0;
            }

            let color = match tabela[y][x] {
                0 => graphics::Color::from_rgb(0, 128, 0),
                1 => graphics::Color::from_rgb(169, 169, 169),
                7 => graphics::Color::from_rgb(139, 69, 19),
                9 => graphics::BLACK,
                _ => graphics::WHITE,
            };

            draw_hexagon(ctx, x_pos, y_pos, color)?;
        }
    }
    Ok(())
}
impl EventHandler for MainState {
    fn update(&mut self, _ctx: &mut Context) -> GameResult<()> {
        self.client.request_state();
        match self.client.receive_message() {
            Ok(msg) => {
                match msg {
                    Message::UpdateState { tabela, player_turn } => {
                        self.tabela = tabela;
                        self.player_turn = player_turn;
                    }
                    Message::GameResult(result) => {
                        self.game_result = result;
                    }
                    _ => {}
                }
            }
            Err(e) => {
                println!("Eroare la primirea mesajului: {:?}", e);
            }
        }
        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult<()> {
        graphics::clear(ctx, graphics::WHITE);
        let _ =afiseaza_tabela(ctx, &self.tabela);

        draw_status(ctx, &self.player_turn, self.game_result)?;
        graphics::present(ctx)?;
        Ok(())
    }

    fn key_down_event(&mut self, ctx: &mut Context, keycode: KeyCode, _keymod: KeyMods, _repeat: bool) {
        if keycode == KeyCode::Escape {
            println!("Jocul se inchide.");
            ggez::event::quit(ctx);
        }
    }

    fn mouse_button_down_event(&mut self, _ctx: &mut Context, button: MouseButton, x: f32, y: f32) {
        if button == MouseButton::Left {
            println!("Click la coordonatele: ({}, {})", x, y);
            let adjusted_y = ((y - 15.0) / 32.0).floor();
            let row = adjusted_y as usize;

            let adjusted_x = if row % 2 == 0 {
                (x - 50.0 - 17.0) / 37.0
            } else {
                (x - 50.0) / 37.0
            };

            let col = adjusted_x.round() as usize;

            if col < self.tabela[0].len() && row < self.tabela.len() {
                match self.player_turn {
                    PlayerTurn::Mouse => {
                        if casuta_libera_mouse(&self.tabela, col, row) {
                            self.tabela[self.pos_y][self.pos_x] = 0;
                            self.pos_y = row;
                            self.pos_x = col;
                            self.tabela[self.pos_y][self.pos_x] = 1;
                            self.client.send_message(Message::PlayerMove { x: col, y: row });
                            self.player_turn = PlayerTurn::Obstacle;
                        } else {
                            println!("Mutare invalida pentru soarece!");
                        }
                    }
                    PlayerTurn::Obstacle => {
                        if casuta_libera(&self.tabela, col, row) {
                            place_obstacol(&mut self.tabela, col, row);
                            self.player_turn = PlayerTurn::Mouse;
                            self.client.send_message(Message::PlayerMove { x: col, y: row });
                        } else {
                            println!("Spatiu ocupat. Alege alt spatiu.");
                        }
                    }
                }
            }
        }
    }
}


fn main() -> GameResult<()> {
    let mut client_name = String::new();
    println!("Introduceti numele clientului:");
    std::io::stdin().read_line(&mut client_name).unwrap();
    let client_name = client_name.trim().to_string();
    let server_address = "127.0.0.1:12345";
    let stream = TcpStream::connect(server_address).expect("Conexiunea la server a esuat!");
    println!("Conectat la serverul de la {}", server_address);
    let mut client = Client { stream };
    client.send_message(Message::JoinRoom {
        room: "default_room".to_string(),
        client_name,
    });

    let (mut ctx, mut event_loop) = ContextBuilder::new("TrapTheMouse", "Autorul")
        .window_setup(ggez::conf::WindowSetup::default().title("TrapTheMouse"))
        .window_mode(ggez::conf::WindowMode::default().dimensions(1000.0, 600.0))
        .build()
        .expect("Nu am putut crea contextul GGEZ!");

    let mut state = MainState::new(client)?;
    event::run(&mut ctx, &mut event_loop, &mut state)
}
