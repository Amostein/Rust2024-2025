use ggez::{Context, GameResult, graphics, ContextBuilder, event};
use ggez::nalgebra as na;
use ggez::event::{MouseButton, KeyCode, KeyMods, EventHandler};
use rand::Rng;

struct MainState {
    tabela: [[i32; 13]; 13],
    pos_x: usize,
    pos_y: usize,
    game_result: i32,
    turn_o: bool,
    turn_s: bool,
}

impl MainState {
    fn new() -> GameResult<MainState> {
        let mut state = MainState {
            tabela: [[0; 13]; 13],
            pos_x: 6,
            pos_y: 6,
            game_result: 0,
            turn_s: true,
            turn_o: false,
        };
        init_tabela(&mut state.tabela);
        Ok(state)
    }
}

fn init_tabela(tabela: &mut [[i32; 13]; 13]) {
    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            tabela[y][x] = 0;
        }
    }

    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            if x == 0 || x == 12 || y == 0 || y == 12 {
                tabela[y][x] = 9;
            }
        }
    }

    tabela[6][6] = 1; // poziția de start a șoarecelui
    
    let mut rng = rand::thread_rng();
    let nr_random = rng.gen_range(4..7);
    let mut gata = 0;
    while gata < nr_random {
        let rx = rng.gen_range(1..11);
        let ry = rng.gen_range(1..11);
        if casuta_libera(tabela, rx, ry) {
            tabela[rx][ry] = 7;
            gata += 1;
        }
    }

}

fn casuta_libera(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if x >= tabela[0].len() || y >= tabela.len() {
        return false;
    }
    tabela[y][x] != 1 && tabela[y][x] != 7 && tabela[y][x] != 9
}

fn casuta_libera_mouse(tabela: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if x >= tabela[0].len() || y >= tabela.len() {
        return false;
    }
    tabela[y][x] != 7
}

fn place_obstacol(tabela: &mut [[i32; 13]; 13], x: usize, y:usize)
{
    if casuta_libera(tabela, x, y) 
    {
        tabela[y][x] = 7;
        println!("Obstacol plasat la coordonatele ({}, {}).", x, y);
    } 
    else 
    {
        println!("Coordonate invalide sau loc ocupat! Obstacolul nu a fost plasat.");
    }
}

fn draw_hexagon(ctx: &mut Context, x: f32, y: f32, color: graphics::Color) -> GameResult<()>
{
    let points = [
        na::Point2::new(x, y),
        na::Point2::new(x - 17.0, y - 10.0),
        na::Point2::new(x - 17.0, y - 30.0),
        na::Point2::new(x, y - 40.0),
        na::Point2::new(x + 18.0, y - 30.0),
        na::Point2::new(x + 18.0, y - 10.0),
    ];

    let mesh = graphics::Mesh::new_polygon(ctx, graphics::DrawMode::fill(), &points, color)?;
    graphics::draw(ctx, &mesh, graphics::DrawParam::default())?;
    Ok(())
}

fn draw_status(ctx: &mut Context, turn_o: bool, turn_s: bool, game_result: i32) -> GameResult<()> {
    if game_result != 0 {
        let text1;
        if game_result == 2 {
            text1 = "Soarecele este blocat.";
        } else if game_result == 1 {
            text1 = "Soarecele a evadat.";
        } else {
            return Ok(()); // Dacă nu avem un rezultat, nu facem nimic
        }

        let status_text = graphics::Text::new((text1, graphics::Font::default(), 24.0));
        let pos = na::Point2::new(600.0, 250.0); // Poziția textului în partea dreaptă
        graphics::draw(ctx, &status_text, (pos, graphics::BLACK))?;
        return Ok(());
    }

    let text = if turn_o {
        "Este randul pentru obstacole."
    } else if turn_s {
        "Este randul soarecelui."
    } else {
        "Joc terminat."
    };

    let status_text = graphics::Text::new((text, graphics::Font::default(), 24.0));
    let pos = na::Point2::new(600.0, 100.0); // Poziția textului în partea dreaptă
    graphics::draw(ctx, &status_text, (pos, graphics::BLACK))?;

    Ok(())
}

fn afiseaza_tabela(ctx: &mut Context, tabela: &[[i32; 13]; 13]) -> GameResult<()> {
    for y in 0..tabela.len() {
        for x in 0..tabela[y].len() {
            let mut x_pos = (x as f32 * 37.0) + 50.0;
            let y_pos = (y as f32 * 32.0) + 50.0;
            if y % 2 == 0 {
                x_pos += 17.0;
            }

            let color = match tabela[y][x] {
                0 => graphics::Color::from_rgb(0, 128, 0),    // Verde
                1 => graphics::Color::from_rgb(169, 169, 169), //gri
                7 => graphics::Color::from_rgb(139, 69, 19), // Maro
                9 => graphics::BLACK,                        // Negru
                _ => graphics::WHITE,                        // Alb (fallback)
            };

            draw_hexagon(ctx, x_pos, y_pos, color)?;
        }
    }
    Ok(())
}

fn is_mouse_trapped(a: &[[i32; 13]; 13], x: usize, y: usize) -> bool {
    if y % 2 == 0 {
        if x > 0 && y > 0 && a[y - 1][x] != 7 { return false; }                            // stg sus
        if y > 0 && x < a[0].len() - 1 && a[y - 1][x + 1] != 7 { return false; }           // dr sus
        if x < a[0].len() - 1 && a[y][x + 1] != 7 { return false; }                        // dr
        if y < a.len() - 1 && x < a[0].len() - 1 && a[y + 1][x + 1] != 7 { return false; } // dr jos
        if y < a.len() - 1 && x > 0 && a[y + 1][x] != 7 { return false; }                  // stg jos
        if x > 0 && a[y][x - 1] != 7 { return false; }                                     // stg
    } else {
        if y > 0 && x > 0 && a[y - 1][x - 1] != 7 { return false; }                 // stg
        if y > 0 && a[y - 1][x] != 7 { return false; }                              // dr sus
        if x < a[0].len() - 1 && a[y][x + 1] != 7 { return false; }                 // dr
        if y < a.len() - 1 && a[y + 1][x] != 7 { return false; }                    // dr jos
        if y < a.len() - 1 && x > 0 && a[y + 1][x - 1] != 7 { return false; }       // stg jos
        if x > 0 && a[y][x - 1] != 7 { return false; }                              // stg
    }
    true
}
fn check_win(tabela: &[[i32;13];13], x:usize, y:usize)->bool
{
    tabela[y][x]==9
}

impl EventHandler for MainState {
    fn update(&mut self, _ctx: &mut Context) -> GameResult<()> {
        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult<()> {
        graphics::clear(ctx, graphics::WHITE);
        afiseaza_tabela(ctx, &self.tabela)?;
        draw_status(ctx, self.turn_o, self.turn_s, self.game_result)?;
        graphics::present(ctx)?;
        Ok(())
    }

    fn key_down_event(&mut self, ctx: &mut Context, keycode: KeyCode, _keymod: KeyMods, _repeat: bool) {
        if keycode == KeyCode::Escape {
            println!("Jocul se închide.");
            ggez::event::quit(ctx);
            return;
        }
    }

    fn mouse_button_down_event(&mut self, _ctx: &mut Context, button: MouseButton, x: f32, y: f32) {
        if button == MouseButton::Left {
            println!("Click la coordonatele: ({}, {})", x, y);

            // Ajustează pentru decalajul dintre rânduri pare/impare
            let adjusted_y = ((y - 15.0) / 32.0).floor();
            let row = adjusted_y as usize;

            // Calcul hex_x în funcție de rând (pare/impare)
            let adjusted_x = if row % 2 == 0 {
                (x - 50.0 - 17.0) / 37.0
            } else {
                (x - 50.0) / 37.0
            };

            let col = adjusted_x.round() as usize;

            if col < self.tabela[0].len() && row < self.tabela.len() {
                if self.turn_s {
                    // Mutarea șoarecelui
                    let is_even_row = self.pos_y % 2 == 0;
                    let neighbors = if is_even_row {
                        vec![
                            (self.pos_y - 1, self.pos_x),      // stg sus
                            (self.pos_y - 1, self.pos_x + 1), // dr sus
                            (self.pos_y, self.pos_x - 1),     // stg
                            (self.pos_y, self.pos_x + 1),     // dr
                            (self.pos_y + 1, self.pos_x),     // stg jos
                            (self.pos_y + 1, self.pos_x + 1), // dr jos
                        ]
                    } else {
                        vec![
                            (self.pos_y - 1, self.pos_x - 1), // stg sus
                            (self.pos_y - 1, self.pos_x),     // dr sus
                            (self.pos_y, self.pos_x - 1),     // stg
                            (self.pos_y, self.pos_x + 1),     // dr
                            (self.pos_y + 1, self.pos_x - 1), // stg jos
                            (self.pos_y + 1, self.pos_x),     // dr jos
                        ]
                    };
                    
                    if neighbors.contains(&(row, col)) && casuta_libera_mouse(&self.tabela, col, row) {
                        if check_win(&self.tabela,row,col){
                            println!("Soarecele a iesit!");
                            self.game_result=1;
                        }
                        self.tabela[self.pos_y][self.pos_x] = 0; // Ștergem șoarecele de la poziția curentă
                        self.pos_y = row;
                        self.pos_x = col;
                        self.tabela[self.pos_y][self.pos_x] = 1; // Mutăm șoarecele
                        println!("Soarecele s-a mutat la ({}, {}).", row, col);

                        self.turn_s = false; // Încheiem rândul șoarecelui
                        self.turn_o = true;  // Este rândul pentru obstacole
                    } else {
                        println!("Mutare invalidă pentru șoarece!");
                    }
                } else if self.turn_o {
                    // Plasarea obstacolului
                    if casuta_libera(&self.tabela, col, row) {
                        place_obstacol(&mut self.tabela, col, row);
                        self.turn_o = false; // Încheiem rândul pentru obstacole
                        self.turn_s = true;  // Este rândul șoarecelui
                        if is_mouse_trapped(&self.tabela, self.pos_x, self.pos_y) {
                            self.game_result = 2;
                        }
                    } else {
                        println!("Spatiu ocupat. Alege alt spatiu.");
                    }
                }
            }
        }
    }
}


fn main() -> GameResult {
    let (mut ctx, mut event_loop) = ContextBuilder::new("Hexagon Game", "Author")
        .window_setup(ggez::conf::WindowSetup::default().title("Hexagon Game"))
        .window_mode(ggez::conf::WindowMode::default().dimensions(1000.0, 600.0))
        .build()?;

    let mut state = MainState::new()?;
    event::run(&mut ctx, &mut event_loop, &mut state)
}
