use std::thread;
use std::sync::mpsc;
use tokio::runtime::Runtime;
use tokio::net::{TcpListener};
use tokio_tungstenite::accept_async;
use ggez::{Context, GameResult, graphics, ContextBuilder, event};
use ggez::nalgebra as na;
use ggez::event::{MouseButton, KeyCode, KeyMods, EventHandler};
use rand::Rng;
// Codul existent pentru joc rămâne aici...
// Codul complet pentru structura MainState, metodele și evenimentele de input.

fn main() -> GameResult {
    let (tx, rx) = mpsc::channel::<String>(); // Canal pentru comunicare între server și joc

    // Pornește serverul WebSocket într-un thread separat
    thread::spawn(move || {
        let rt = Runtime::new().unwrap();
        rt.block_on(async move {
            let addr = "127.0.0.1:9001";
            let listener = TcpListener::bind(addr).await.unwrap();
            println!("Server WebSocket pornit la {}", addr);

            while let Ok((stream, _)) = listener.accept().await {
                let peer = stream.peer_addr().unwrap();
                println!("Conexiune nouă de la {}", peer);

                tokio::spawn(async move {
                    let ws_stream = accept_async(stream).await.unwrap();
                    println!("WebSocket acceptat de la {}", peer);

                    let (write, mut read) = ws_stream.split();

                    while let Some(msg) = read.next().await {
                        match msg {
                            Ok(tungstenite::Message::Text(text)) => {
                                println!("Mesaj primit: {}", text);
                                // Trimite mesajul către bucla jocului
                                tx.send(text).unwrap();
                            }
                            Ok(_) => {}
                            Err(e) => {
                                println!("Eroare: {:?}", e);
                                break;
                            }
                        }
                    }
                });
            }
        });
    });

    let (mut ctx, mut event_loop) = ContextBuilder::new("Hexagon Game", "Author")
        .window_setup(ggez::conf::WindowSetup::default().title("Hexagon Game"))
        .window_mode(ggez::conf::WindowMode::default().dimensions(1000.0, 600.0))
        .build()?;

    let mut state = MainState::new()?;

    // Integrează canalul de mesaje în joc
    state.channel_rx = Some(rx);

    event::run(&mut ctx, &mut event_loop, &mut state)
}

// Adaugă un câmp nou în `MainState` pentru a primi mesaje
struct MainState {
    tabela: [[i32; 13]; 13],
    pos_x: usize,
    pos_y: usize,
    game_result: i32,
    turn_o: bool,
    turn_s: bool,
    channel_rx: Option<mpsc::Receiver<String>>, // Canal pentru mesaje de la WebSocket
}

// În metoda `update`, verifică mesajele primite
impl EventHandler for MainState {
    fn update(&mut self, _ctx: &mut Context) -> GameResult<()> {
        if let Some(ref rx) = self.channel_rx {
            while let Ok(message) = rx.try_recv() {
                println!("Mesaj primit din WebSocket: {}", message);
                // Procesează mesajele și actualizează starea jocului
                if message == "move_up" && self.turn_s {
                    // Exemplu de mutare pentru șoarece
                    if self.pos_y > 0 && casuta_libera_mouse(&self.tabela, self.pos_x, self.pos_y - 1) {
                        self.tabela[self.pos_y][self.pos_x] = 0;
                        self.pos_y -= 1;
                        self.tabela[self.pos_y][self.pos_x] = 1;
                        self.turn_s = false;
                        self.turn_o = true;
                    }
                }
                // Alte mesaje pentru obstacole sau mutări
            }
        }
        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult<()> {
        // Codul de desen rămâne la fel
        graphics::clear(ctx, graphics::WHITE);
        afiseaza_tabela(ctx, &self.tabela)?;
        draw_status(ctx, self.turn_o, self.turn_s, self.game_result)?;
        graphics::present(ctx)?;
        Ok(())
    }
}
