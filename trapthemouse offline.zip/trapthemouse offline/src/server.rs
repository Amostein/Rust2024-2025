use tokio::sync::{mpsc, Mutex};
use tokio::net::TcpListener;
use tokio_tungstenite::tungstenite::protocol::Message;
use tokio_tungstenite::accept_async;
use serde::{Serialize, Deserialize};
use futures_util::{StreamExt, SinkExt};
use std::collections::HashMap;
use std::sync::Arc;

#[derive(Serialize, Deserialize, Debug)]
struct GameState {
    board: [[i32; 13]; 13],
    mouse_pos: (usize, usize),
    turn_obstacle: bool,
    game_result: i32,
}

impl GameState {
    fn new() -> Self {
        let mut board = [[0; 13]; 13];
        for y in 0..13 {
            for x in 0..13 {
                if x == 0 || x == 12 || y == 0 || y == 12 {
                    board[y][x] = 9;
                }
            }
        }
        board[6][6] = 1; // Start position for the mouse
        Self {
            board,
            mouse_pos: (6, 6),
            turn_obstacle: true,
            game_result: 0,
        }
    }

    fn place_obstacle(&mut self, x: usize, y: usize) -> Result<(), String> {
        if x >= 13 || y >= 13 || self.board[y][x] != 0 {
            return Err("Invalid position for obstacle".to_string());
        }
        self.board[y][x] = 7;
        Ok(())
    }

    fn move_mouse(&mut self, x: usize, y: usize) -> Result<(), String> {
        if x >= 13 || y >= 13 || self.board[y][x] != 0 {
            return Err("Invalid move for mouse".to_string());
        }
        self.board[self.mouse_pos.1][self.mouse_pos.0] = 0;
        self.mouse_pos = (x, y);
        self.board[y][x] = 1;
        Ok(())
    }
}

type Tx = mpsc::UnboundedSender<Message>;
type Rx = mpsc::UnboundedReceiver<Message>;

type Room = Arc<Mutex<HashMap<String, Tx>>>;

type GameRooms = Arc<Mutex<HashMap<String, (Room, GameState)>>>;

#[tokio::main]
async fn main() {
    let listener = TcpListener::bind("127.0.0.1:8080").await.unwrap();
    let game_rooms: GameRooms = Arc::new(Mutex::new(HashMap::new()));

    println!("Server listening on 127.0.0.1:8080");

    while let Ok((stream, _)) = listener.accept().await {
        let game_rooms = Arc::clone(&game_rooms);

        tokio::spawn(async move {
            if let Ok(ws_stream) = accept_async(stream).await {
                let (tx, mut rx) = mpsc::unbounded_channel();
                let (mut ws_tx, mut ws_rx) = ws_stream.split();

                // Handle incoming messages
                while let Some(Ok(msg)) = ws_rx.next().await {
                    if let Message::Text(text) = &msg {
                        let command: serde_json::Value = serde_json::from_str(text).unwrap();

                        match command["type"].as_str() {
                            Some("create_room") => {
                                let room_id = command["room_id"].as_str().unwrap().to_string();
                                let mut rooms = game_rooms.lock().await;
                                if !rooms.contains_key(&room_id) {
                                    rooms.insert(room_id.clone(), (Arc::new(Mutex::new(HashMap::new())), GameState::new()));
                                    println!("Room {} created", room_id);
                                }
                                let _ = tx.send(Message::Text("Room created".to_string()));
                            }
                            Some("join_room") => {
                                let room_id = command["room_id"].as_str().unwrap().to_string();
                                let player_id = command["player_id"].as_str().unwrap().to_string();
                                let mut rooms = game_rooms.lock().await;
                                if let Some((room, _)) = rooms.get(&room_id) {
                                    let mut room_lock = room.lock().await;
                                    room_lock.insert(player_id.clone(), tx.clone());
                                    println!("Player {} joined room {}", player_id, room_id);
                                    let _ = tx.send(Message::Text("Joined room".to_string()));
                                } else {
                                    let _ = tx.send(Message::Text("Room not found".to_string()));
                                }
                            }
                            Some("place_obstacle") => {
                                let room_id = command["room_id"].as_str().unwrap().to_string();
                                let x = command["x"].as_u64().unwrap() as usize;
                                let y = command["y"].as_u64().unwrap() as usize;
                                let mut rooms = game_rooms.lock().await;
                                if let Some((_, game_state)) = rooms.get_mut(&room_id) {
                                    let mut game_state_lock = game_state;
                                    if game_state_lock.turn_obstacle {
                                        if game_state_lock.place_obstacle(x, y).is_ok() {
                                            game_state_lock.turn_obstacle = false;
                                            let state = serde_json::to_string(&game_state_lock).unwrap();
                                            for player in game_state_lock.lock().await.values() {
                                                let _ = player.send(Message::Text(state.clone()));
                                            }
                                        } else {
                                            let _ = tx.send(Message::Text("Invalid obstacle position".to_string()));
                                        }
                                    } else {
                                        let _ = tx.send(Message::Text("Not your turn".to_string()));
                                    }
                                }
                            }
                            Some("move_mouse") => {
                                let room_id = command["room_id"].as_str().unwrap().to_string();
                                let x = command["x"].as_u64().unwrap() as usize;
                                let y = command["y"].as_u64().unwrap() as usize;
                                let mut rooms = game_rooms.lock().await;
                                if let Some((_, game_state)) = rooms.get_mut(&room_id) {
                                    let mut game_state_lock = game_state;
                                    if !game_state_lock.turn_obstacle {
                                        if game_state_lock.move_mouse(x, y).is_ok() {
                                            game_state_lock.turn_obstacle = true;
                                            let state = serde_json::to_string(&game_state_lock).unwrap();
                                            for player in game_state_lock.lock().await.values() {
                                                let _ = player.send(Message::Text(state.clone()));
                                            }
                                        } else {
                                            let _ = tx.send(Message::Text("Invalid mouse move".to_string()));
                                        }
                                    } else {
                                        let _ = tx.send(Message::Text("Not your turn".to_string()));
                                    }
                                }
                            }
                            _ => {}
                        }
                    }
                }
            }
        });
    }
}
